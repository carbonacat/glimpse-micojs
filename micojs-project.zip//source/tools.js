// tools.js

const bgColor = setPen(0, 0, 0);
const txtColor = setPen(200, 200, 255);